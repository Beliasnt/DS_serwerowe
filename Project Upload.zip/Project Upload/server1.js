const express = require("express")
const app = express()
const PORT = 3000;
const path = require("path")
const hbs = require('express-handlebars');
const formidable = require('formidable');
const { appendFile } = require("fs");


app.set('views', path.join(__dirname, 'views'));
app.engine('hbs', hbs({ defaultLayout: 'main.hbs' }));
app.set('view engine', 'hbs');

app.use(
    express.urlencoded({
        extended: true
    })
)

//wyświetlenie indexu
app.get("/", function (req, res) {
    res.render('index.hbs',);

})

app.post('/handleUpload', function (req, res) {
    let form = formidable({});
    form.keepExtensions = true
    form.parse(req, function (err, files) {
        console.log("----- przesłane formularzem pliki ------");
        console.log(files);
        let tablica1 = [files]
    });
    res.render('filemanager.hbs')
});

app.get("/filemanager", function (req, res) {
    res.render('filemanager.hbs',);
    
})



app.use(express.static('static'))

app.listen(PORT, function () {
    console.log("start serwera na porcie " + PORT)
})
