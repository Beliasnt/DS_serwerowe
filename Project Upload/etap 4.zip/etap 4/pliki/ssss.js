<script>
console.log('przykładowa strona')
</script>